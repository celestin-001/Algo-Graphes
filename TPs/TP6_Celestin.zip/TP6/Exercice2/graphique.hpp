
int createWindow(MatriceAdjacence &m);
void drawGraph(MatriceAdjacence &m);
void drawPaths(MatriceAdjacence mat, int *parents);
void waitForEnd();
void destroyWindow();
